<?php
/**
 * E-mail automatizmusok (Action Scheduler – a WooCommerce része):
 *  - elhagyott kosár: két emlékeztető (alapból 3 és 24 óra) a kosár visszaállító linkjével – reklámlevél, ezért csak
 *    hírlevél-feliratkozónak (Grt. 6. § (1), nincs „soft opt-in”); a feliratkozás pipája az e-mail mező mellett van, és
 *    bejelölve már a pénztár közben feliratkoztat (kivéve: visszavonja); más címet a pénztár nem is rögzít;
 *  - használati útmutató a teljesített rendelés után;
 *  - újrarendelés emlékeztető fogyóeszközöknél (füstölő);
 *  - értékelés kérése személyes, ellenőrzött linkkel (lásd reviews.php).
 * A levelek szövege, kapcsolója és időzítése: WooCommerce → Mandala levelek (mailer.php).
 */

defined('ABSPATH') || exit;

/** A rendeléses levelek közös helyőrzői. */
function mandala_mail_order_vars(WC_Order $order): array
{
    return ['keresztnev' => $order->get_billing_first_name() ?: __('Vásárlónk', 'mandala'), 'rendeles' => $order->get_order_number()];
}

function mandala_schedule(int $delay_seconds, string $hook, array $args): void
{
    if (function_exists('as_schedule_single_action') && !as_next_scheduled_action($hook, $args, MANDALA_AS_GROUP)) {
        as_schedule_single_action(time() + $delay_seconds, $hook, $args, MANDALA_AS_GROUP);
    }
}

/* ---------- Elhagyott kosár ---------- */

/**
 * A pénztár az e-mail megadásakor és a hírlevél-pipa váltásakor jelez (wc-ajax=mandala_capture). A bejelölt pipa
 * (newsletter=1) a pipa szövegével azonnal feliratkoztat – addig az emlékeztető egy olyan pipán múlt, ami csak
 * rendeléskor számított, így a félbehagyott pénztárra soha nem ment levél (2026-11-01, Áron) –; a kivett pipa a
 * pénztárban adott feliratkozást visszavonja. Csak hírlevél-feliratkozó kosarát tesszük el: más címre az emlékeztető
 * úgysem mehet (reklámlevél hozzájárulás nélkül), így az adatra sincs szükség.
 */
add_action('wc_ajax_mandala_capture', function () {
    mandala_verify_cart_request();
    $email = strtolower(sanitize_email(wp_unslash($_POST['email'] ?? '')));
    $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
    $nl = isset($_POST['newsletter']) ? (string) wp_unslash($_POST['newsletter']) : ''; // phpcs:ignore
    if (is_email($email) && function_exists('WC') && WC()->session) {
        if ($nl === '1') {
            mandala_newsletter_subscribe($email, 'penztar', mandala_consent_wording(__('Pénztár', 'mandala'), mandala_consent_text('checkout')), ['name' => $name, 'user_id' => get_current_user_id()]);
            WC()->session->set('mandala_nl_checkout', $email);
        } elseif ($nl === '0' && WC()->session->get('mandala_nl_checkout') === $email) {
            mandala_newsletter_withdraw($email, 'penztar', ['user_id' => get_current_user_id()]);
            WC()->session->set('mandala_nl_checkout', '');
            mandala_abandoned_forget($email);
            wp_send_json(['ok' => false]);
        }
    }
    if (!mandala_automation_on('abandoned') || !is_email($email) || !WC()->cart || WC()->cart->is_empty() || !mandala_marketing_consent($email)) {
        wp_send_json(['ok' => false]);
    }
    $items = [];
    foreach (WC()->cart->get_cart() as $item) {
        $items[] = [(int) $item['product_id'], (int) $item['variation_id'], (int) $item['quantity']];
    }
    $carts = (array) get_option('mandala_abandoned', []);
    $carts[$email] = ['items' => $items, 'time' => time(), 'name' => $name];
    // Legfeljebb 2000 nyitott kosarat tartunk (a legrégebbiek esnek ki).
    if (count($carts) > 2000) {
        uasort($carts, fn($a, $b) => $b['time'] <=> $a['time']);
        $carts = array_slice($carts, 0, 2000, true);
    }
    update_option('mandala_abandoned', $carts, false);
    mandala_abandoned_unschedule($email);
    $s = mandala_automation_settings();
    mandala_schedule((int) $s['abandoned_hours'] * HOUR_IN_SECONDS, 'mandala_mail_abandoned', [$email]);
    if (mandala_automation_on('abandoned2')) {
        mandala_schedule(max((int) $s['abandoned2_hours'], (int) $s['abandoned_hours'] + 1) * HOUR_IN_SECONDS, 'mandala_mail_abandoned2', [$email]);
    }
    wp_send_json(['ok' => true]);
});

function mandala_abandoned_unschedule(string $email): void
{
    if (function_exists('as_unschedule_all_actions')) {
        as_unschedule_all_actions('mandala_mail_abandoned', [$email], MANDALA_AS_GROUP);
        as_unschedule_all_actions('mandala_mail_abandoned2', [$email], MANDALA_AS_GROUP);
    }
}

/** A félretett kosár és mindkét emlékeztető törlése (rendelés, visszavont feliratkozás). */
function mandala_abandoned_forget(string $email): void
{
    $carts = (array) get_option('mandala_abandoned', []);
    if (isset($carts[$email])) {
        unset($carts[$email]);
        update_option('mandala_abandoned', $carts, false);
    }
    mandala_abandoned_unschedule($email);
}

/** Rendeléskor az emlékeztetők törlődnek. */
add_action('woocommerce_checkout_order_created', function (WC_Order $order) {
    mandala_abandoned_forget(strtolower($order->get_billing_email()));
});

/**
 * Egy emlékeztető kiküldése ($type: abandoned | abandoned2). Az első után a kosár megmarad a másodikhoz (ha az be van
 * kapcsolva); közben leadott rendelés (másik eszközről is) vagy leiratkozás mindkettőt elhagyja.
 */
function mandala_abandoned_send(string $email, string $type): void
{
    $carts = (array) get_option('mandala_abandoned', []);
    $cart = $carts[$email] ?? null;
    if (!$cart || !mandala_automation_on($type)) { // a hozzájárulást a mandala_mail() nézi és naplózza
        if ($cart && $type === 'abandoned2') {
            mandala_abandoned_forget($email);
        }
        return;
    }
    $orders = wc_get_orders(['billing_email' => $email, 'date_created' => '>' . $cart['time'], 'limit' => 1, 'return' => 'ids']);
    $last = $type === 'abandoned2' || !mandala_automation_on('abandoned2');
    if ($orders || $last) {
        unset($carts[$email]);
        update_option('mandala_abandoned', $carts, false);
    }
    if ($orders) {
        mandala_abandoned_unschedule($email);
        return;
    }
    $rows = '';
    foreach ($cart['items'] as [$pid, $vid, $qty]) {
        $product = wc_get_product($vid ?: $pid);
        if ($product && $product->is_purchasable()) {
            $rows .= mandala_mail_product_row($product, esc_html($qty . ' db · ') . wp_kses_post(wc_price(wc_get_price_to_display($product) * $qty)));
        }
    }
    if (!$rows) {
        return;
    }
    $restore = add_query_arg(['mandala_restore' => rawurlencode($email), 'k' => mandala_token('restore', $email, (string) $cart['time']), 't' => $cart['time']], home_url('/'));
    // A visszaállításhoz a kosár tartalma a linkhez kötve 7 napig marad meg.
    set_transient('mandala_restore_' . md5($email . $cart['time']), $cart['items'], 7 * DAY_IN_SECONDS);
    mandala_mail($type, $email, ['keresztnev' => $cart['name'] ?: __('Vásárlónk', 'mandala')], ['termekek' => $rows, 'gomb' => mandala_mail_button($restore, __('Rendelés folytatása', 'mandala'))]);
}

add_action('mandala_mail_abandoned', fn($email) => mandala_abandoned_send((string) $email, 'abandoned'));
add_action('mandala_mail_abandoned2', fn($email) => mandala_abandoned_send((string) $email, 'abandoned2'));

/** Kosár visszaállítása a levél linkjéből. */
add_action('wp_loaded', function () {
    if (empty($_GET['mandala_restore']) || empty($_GET['k']) || !function_exists('WC') || !WC()->cart) {
        return;
    }
    $email = strtolower(sanitize_email(wp_unslash($_GET['mandala_restore'])));
    $time = (string) absint($_GET['t'] ?? 0);
    if (!hash_equals(mandala_token('restore', $email, $time), sanitize_text_field(wp_unslash($_GET['k'])))) {
        return;
    }
    $items = get_transient('mandala_restore_' . md5($email . $time));
    if (is_array($items) && WC()->cart->is_empty()) {
        foreach ($items as [$pid, $vid, $qty]) {
            WC()->cart->add_to_cart($pid, $qty, $vid);
        }
    }
    WC()->customer?->set_billing_email($email);
    wp_safe_redirect(wc_get_checkout_url());
    exit;
}, 30);

/* ---------- Teljesített rendelés után ---------- */

add_action('woocommerce_order_status_completed', function ($order_id) {
    $s = mandala_automation_settings();
    if (mandala_automation_on('care')) {
        mandala_schedule((int) $s['care_days'] * DAY_IN_SECONDS, 'mandala_mail_care', [(int) $order_id]);
    }
    if (mandala_automation_on('review')) {
        mandala_schedule((int) $s['review_days'] * DAY_IN_SECONDS, 'mandala_mail_review', [(int) $order_id]);
    }
    if (mandala_automation_on('reorder') && mandala_order_has_category(wc_get_order($order_id), array_map('trim', explode(',', $s['reorder_cats'])))) {
        mandala_schedule(mandala_reorder_delay(wc_get_order($order_id)), 'mandala_mail_reorder', [(int) $order_id]);
    }
});

/**
 * Személyre szabott utánrendelési időpont: ha a vásárló már többször vett fogyóeszközt, a saját
 * ritmusa (két rendelés közti átlagos napok, 14–150 nap között) egy héttel előbb; különben az
 * alapidő, a vett mennyiséggel arányosan (3 csomag füstölő → háromszoros idő, legfeljebb 3×).
 */
function mandala_reorder_delay(WC_Order $order): int
{
    $s = mandala_automation_settings();
    $cats = array_map('trim', explode(',', $s['reorder_cats']));
    $dates = [];
    foreach (wc_get_orders(['billing_email' => $order->get_billing_email(), 'status' => ['processing', 'completed'], 'limit' => 20, 'orderby' => 'date', 'order' => 'ASC', 'type' => 'shop_order']) as $o) {
        if (mandala_order_has_category($o, $cats) && $o->get_date_created()) {
            $dates[] = $o->get_date_created()->getTimestamp();
        }
    }
    if (count($dates) >= 2) {
        $gaps = [];
        for ($i = 1; $i < count($dates); $i++) {
            $gaps[] = ($dates[$i] - $dates[$i - 1]) / DAY_IN_SECONDS;
        }
        $avg = array_sum($gaps) / count($gaps);
        return (int) round(max(14, min(150, $avg - 7)) * DAY_IN_SECONDS);
    }
    $units = 0;
    foreach ($order->get_items() as $item) {
        if (has_term($cats, 'product_cat', $item->get_product_id())) {
            $units += (int) $item->get_quantity();
        }
    }
    return (int) $s['reorder_days'] * max(1, min(3, $units)) * DAY_IN_SECONDS;
}

function mandala_order_has_category(?WC_Order $order, array $cats): bool
{
    if (!$order) {
        return false;
    }
    foreach ($order->get_items() as $item) {
        if (has_term($cats, 'product_cat', $item->get_product_id())) {
            return true;
        }
    }
    return false;
}

add_action('mandala_mail_care', function ($order_id) {
    $order = wc_get_order($order_id);
    if (!$order || !mandala_automation_on('care')) {
        return;
    }
    do_action('mandala_before_order_mail', $order);
    $rows = '';
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        $ritual = $product ? (string) $product->get_meta('_mandala_ritual') : '';
        if ($product && $ritual && !$product->get_meta('_mandala_ticket_for')) {
            $rows .= mandala_mail_product_row($product, nl2br(esc_html($ritual)));
        }
    }
    if (!$rows) {
        return;
    }
    mandala_mail('care', $order->get_billing_email(), mandala_mail_order_vars($order), ['termekek' => $rows], $order->get_id());
});

add_action('mandala_mail_reorder', function ($order_id) {
    $order = wc_get_order($order_id);
    if (!$order || !mandala_automation_on('reorder')) {
        return;
    }
    // Közben már újrarendelt (fogyóeszközt): nem emlékeztetünk.
    $cats = array_map('trim', explode(',', mandala_automation_settings()['reorder_cats']));
    foreach (wc_get_orders(['billing_email' => $order->get_billing_email(), 'status' => ['processing', 'completed', 'on-hold'], 'date_created' => '>' . $order->get_date_created()->getTimestamp(), 'limit' => 10, 'type' => 'shop_order']) as $newer) {
        if ((int) $newer->get_id() !== (int) $order->get_id() && mandala_order_has_category($newer, $cats)) {
            return;
        }
    }
    do_action('mandala_before_order_mail', $order);
    $cats = array_map('trim', explode(',', mandala_automation_settings()['reorder_cats']));
    $rows = '';
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        if ($product && $product->is_in_stock() && has_term($cats, 'product_cat', $item->get_product_id())) {
            $rows .= mandala_mail_product_row($product, wp_kses_post(wc_price(wc_get_price_to_display($product))), add_query_arg('add-to-cart', $product->get_id(), wc_get_cart_url()));
        }
    }
    if (!$rows) {
        return;
    }
    mandala_mail('reorder', $order->get_billing_email(), mandala_mail_order_vars($order), ['termekek' => $rows, 'gomb' => mandala_mail_button(mandala_url(['cat' => $cats[0]]), __('Új illatok', 'mandala'))], $order->get_id());
});

/* ---------- Pénztár: e-mail rögzítése és tájékoztatás ---------- */

add_filter('woocommerce_billing_fields', function ($fields) {
    if (mandala_automation_on('abandoned') && isset($fields['billing_email'])) {
        $fields['billing_email']['description'] = mandala_automation_on('abandoned2')
            ? __('Ide küldjük a visszaigazolást és a csomagkövetést. Ha feliratkozol a hírlevelünkre, és nem fejezed be a rendelést, legfeljebb kétszer emlékeztetünk.', 'mandala')
            : __('Ide küldjük a visszaigazolást és a csomagkövetést. Ha feliratkoztál a hírlevelünkre, és nem fejezed be a rendelést, egyszer emlékeztetünk.', 'mandala');
    }
    return $fields;
}, 30);
