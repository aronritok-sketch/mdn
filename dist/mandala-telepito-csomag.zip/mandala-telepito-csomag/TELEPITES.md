# Mandala téma – telepítési útmutató

A csomag tartalma:

| Fájl | Mi ez |
|---|---|
| `mandala-telepito-varazslo.zip` | **Telepítő varázsló bővítmény – ezzel kezdd.** Bővítmények → Új hozzáadása → Bővítmény feltöltése → Bekapcsolás. Végigvisz mindenen (benne van a téma is). |
| `mandala-tema.zip` | A WordPress child téma (a varázsló magától telepíti; kézzel: Megjelenés → Témák → Új hozzáadása → Téma feltöltése). |
| `TELEPITES.md` | Ez az útmutató. |
| `UJ-TERMEKEK.md` | Munkafolyamat a webért felelős munkatársnak: új JUTA-termékek élesítése, Claude-os kategória-migráció. |
| `TERHELESI-TESZT.md` | Terheléses teszt (3000 termék, egyszerre vásárlók): eredmények, javítások, szerverbeállítások nagy forgalomhoz. |
| `regi-bolt-export.js` | Ha a régi bolt WooCommerce termékexportja elakad: a régi bolt adminjában, a böngésző konzoljában futtatva adagokban letölti ugyanazt az importálható CSV-t (változatokkal, nagyker árral). |
| Termékek → Új termékek → Beállítások → **Átköltöztetés a régi boltból** | Ha az importált termékek mind a jóváhagyási sorba kerültek (piszkozatként): ugyanazt a CSV-t feltöltve a régi boltban közzétett termékek egy lépésben élesek lesznek, a téma és a régi bolt eltérő nevű dupla kategóriái (pl. „…-2”) összevonódnak, a sorban maradó régi piszkozatoknál pedig nem indul automatikus Claude-hívás. |
| `wp-config-kiegeszites.php` | Sorok a szerver `wp-config.php` fájljába (Claude API-kulcs, memória, ütemezés). |

> **Mindig először tesztszerveren** (az éles bolt másolatán, „staging”) telepítsd és próbáld ki. Az éles bolton
> csak akkor, ha ott minden rendben volt – előtte teljes mentéssel (fájlok + adatbázis).

---

## 0. Gyorsút: a telepítő varázsló

1. Mentés az éles boltról (fájlok + adatbázis) – vagy dolgozz a másolatán.
2. **Bővítmények → Új hozzáadása → Bővítmény feltöltése → `mandala-telepito-varazslo.zip` → Bekapcsolás.**
   A varázsló magától megnyílik (később: bal oldali menü → **Mandala varázsló**).
3. Menj végig a 16 lépésen. Minden lépés magától ellenőrzi, kész-e (zöld pipa), és ahol lehet, egy gombbal
   elvégzi a teendőt; bármikor abbahagyhatod, ott folytatod:

   | Lépés | Mit csinál |
   |---|---|
   | Kezdés és mentés | mentés visszaigazolása |
   | Környezet | PHP, WordPress, memória, HTTPS, **magyar nyelv + fordítások** (gomb), **Budapest időzóna** (gomb), olvasható címek, háttérfeladatok (cron), WebP |
   | Bővítmények | WooCommerce, Wholesale Prices, Számlázz.hu, WP Mail SMTP, Yoast, LiteSpeed Cache – **telepítés és bekapcsolás gombbal**; GLS és Teya: feltöltés / keresés |
   | Téma | iu_theme szülőtéma, iu_custom_blocks, **a Mandala téma telepítése és bekapcsolása** (a varázslóba csomagolva) |
   | Kulcsok és levélküldés | Anthropic (Claude) és MailerLite kulcs **ellenőrzéssel**, próbalevél |
   | Bolt adatai | elérhetőség, nyitvatartás, szállítási határ, utánvét díja, bankszámlaszám |
   | Mandala telepítő | a téma beállításai (élő boltban megerősítés után; visszaállítható) |
   | Termékek importja | CSV import a régi boltból, JUTA, bemutató tartalom törlése |
   | Kategóriák és szűrők (Claude) | **próbafuttatás 20 termékkel**, majd **teljes besorolás** a háttérben (visszavonható) |
   | Szállítás, fizetés, számla | GLS zónák, Teya, utánvét, Számlázz.hu, csomagkövetés |
   | Levelek és MailerLite | SMTP, a levelek szövegének átnézése, MailerLite csoport |
   | AI SEO, gyűjtőoldalak, ajánló, feedek | **egy gombbal indul**, utána magától fut; itt vannak a feed címek |
   | Jogi oldalak | jelzi, ha az ÁSZF / adatkezelés / impresszum kitöltendő részei maradtak |
   | Gyorsítás | gyorsítótár-bővítmény, **meglévő képek WebP-re** (gomb) |
   | Próbarendelések | **önellenőrzés egy gombbal** (oldalak, pénztár, gyorsítótár, tömörítés, HTTPS, oldaltérkép, feed, levélküldés, háttérfeladatok) + 8 próba pipálható listája (kártya, utánvét, utalás, számla, csomagszám, mobil, hírlevél, AI) |
   | Élesítés | ami még nyitott, és az élesítés teendői |

A lenti fejezetek ugyanezt írják le részletesen (ha valamit kézzel csinálnál, vagy elakadnál).

---

## 1. Előfeltételek

**Szerver:** PHP 8.1 vagy újabb (8.2–8.4 ajánlott), WordPress 6.5+, WooCommerce 9–11, legalább 256 MB PHP memória,
a PHP `zip` kiterjesztése (a viszonteladói fotócsomaghoz).

**Keretrendszer (Infinite Unity):** a `mandala` téma child téma, a szülője az **`iu_theme`**. Kell még az
`iu_custom_blocks`, `iu_woocommerce` és `iu_settings` mu-plugin. Ha ezek nincsenek fent, a téma nem fog megjelenni
helyesen – a keretrendszert a fejlesztő / az iu_theme szállítója adja.

**Bővítmények:**

| Bővítmény | Mire kell | Állapot a mandala.hu-n |
|---|---|---|
| WooCommerce | a bolt | fent van |
| GLS bővítmény | szállítási módok, díjak, csomagpont-választó | telepítendő (a GLS módokat a „Magyarország” zónához kell adni) |
| Teya | bankkártyás fizetés, Apple Pay, Google Pay | telepítendő / beállítandó |
| Számlázz.hu | számlázás | telepítendő / beállítandó |
| WooCommerce Wholesale Prices | viszonteladói árak, `wholesale_customer` szerep | fent van |
| Yoast SEO (Premium) | SEO, átirányítások | fent van |
| WPML + WooCommerce Multilingual | angol nyelv | fent van |
| GTM4WP | Google Tag Manager, mérés | fent van |
| SMTP-bővítmény (pl. WP Mail SMTP) | megbízható levélküldés (visszaigazolás, emlékeztetők, értesítők) | **erősen ajánlott** |

A téma telepítő oldala (Megjelenés → Mandala telepítő) mutatja, melyik bővítmény aktív.

---

## 2. Telepítés (tesztszerveren)

1. **Mentés** a tesztszerver adatbázisáról.
2. **Megjelenés → Témák → Új hozzáadása → Téma feltöltése** → `mandala-tema.zip` → **Bekapcsolás**.
   (Ha az `iu_theme` még nincs fent, előbb azt.)
3. **Megjelenés → Mandala telepítő.** Mivel a boltban már vannak termékek, a telepítő **nem fut le magától**:
   lépésenként megmutatja, mit állítana be, és csak a kijelölt lépéseket futtatja. Minden felülírt beállítás
   eredeti értékét elmenti – a „Eredeti beállítások visszaállítása” gombbal bármikor visszaáll.
   Javaslat a mandala.hu-ra:

   | Lépés | Javaslat |
   |---|---|
   | `site` | futtasd (időzóna, dátumformátum; a meglévő URL-ekhez nem nyúl) |
   | `woocommerce` | nézd át: az országot Magyarországra, a levelek feladóját és színeit a Mandaláéra állítja. Ha most is csak belföldre szállítotok: futtasd. |
   | `tax` | futtasd, ha bruttó árakkal és 27% ÁFÁ-val dolgoztok (a mandala.hu így működik) |
   | `shipping` | futtasd (a meglévő zónákhoz nem nyúl, csak ha nincs magyar zóna) |
   | `payments` | futtasd (előre utalás, utánvét) |
   | `attributes`, `categories` | **futtasd** – ezek az új szűrők és az új kategóriafa (a régiekhez nem nyúl) |
   | `pages` | futtasd – az új oldalak; a kezdőlap az új Mandala kezdőlap lesz |
   | `menus` | futtasd – csak üres menühelyre tesz menüt |

   A bemutató tartalmat (mintatermékek, cikkek, kuponok) élő boltban **ne** importáld.
4. **Blokkok ellenőrzése (fejlesztő, egyszer):** a sablonok iu blokkjait a valódi keretrendszerben egyszer el
   kell menteni (`wp-theme/dev/canon.mjs` a forráskódban). A látogató oldalon enélkül is jó, de a
   szerkesztő különben „érvénytelen blokk” jelzést mutathat.
5. **wp-config.php:** a `wp-config-kiegeszites.php` sorai (lásd 3.).
6. **Gyorsítótár:** az oldal-gyorsítótárból zárd ki a `/kosar/`, `/penztar/`, `/fiokom/` oldalakat és a belépett
   felhasználókat (a viszonteladók személyre szabott árat látnak). A `/kedvencek/`, `/csomagkovetes/` és
   `/ertekeles/` oldalakat a téma magától kizárja. Utána ürítsd a gyorsítótárat. Részletek: 9. fejezet.

---

## 3. Szerver beállítások (`wp-config.php`, ütemezés, levelek)

- **Ütemezett feladatok** (e-mail emlékeztetők, értékelés kérése, új termékek értesítője, Claude migráció,
  heti viszonteladói levél): a WooCommerce Action Scheduler futtatja. Kis forgalomnál a WordPress beépített
  időzítője késhet, ezért **valódi cron** ajánlott: `DISABLE_WP_CRON` a wp-config-ba, és a tárhelyen
  **percenként**: `wget -q -O - https://mandala.hu/wp-cron.php?doing_wp_cron >/dev/null 2>&1`
  (a kereső / szűrő termékindexe eladás után a háttérben frissül – percenkénti cronnal 1–2 percen belül;
  oldal-gyorsítótár mellett a WordPress saját időzítője alig fut, ott a valódi cron kötelező)
  (vagy WP-CLI-vel: `wp cron event run --due-now`).
- **Claude (kategória-migráció, új termékek javaslata, AI tanácsadó chat):** `MANDALA_ANTHROPIC_API_KEY` a
  wp-config-ba (az Anthropic Console-ban létrehozott kulcs). Kulcs nélkül ezek a funkciók egyszerűen nem aktívak
  (a chat gomb sem jelenik meg). A Console-ban érdemes havi költségkorlátot is beállítani.
- **MailerLite:** `MANDALA_MAILERLITE_TOKEN` a wp-config-ba (vagy az admin felületen), lásd 4. pont.
- **Levelek:** SMTP-bővítménnyel (pl. a tárhely vagy egy levélküldő szolgáltatás SMTP adataival), hogy a
  levelek ne spambe menjenek. Próba: rendelés a tesztszerveren, és nézd meg, megérkezik-e a visszaigazolás.

---

## 4. Beállítások az adminban (sorrendben)

| Hol | Mit |
|---|---|
| WooCommerce → **Mandala bolt adatai** | e-mail, telefon, cím, nyitvatartás, Facebook / Instagram, ingyenes szállítás határa, utánvét díja |
| WooCommerce → Beállítások → Fizetés → **Előre utalás** | bankszámlaszám (a köszönőoldal és a levél innen veszi) |
| WooCommerce → Beállítások → **Szállítás** | a GLS bővítmény módjai a „Magyarország” zónában (a személyes átvétel a lista végén) |
| **Teya**, **Számlázz.hu** bővítmény | a saját beállításaik; Számlázz.hu: az adószám a rendelésben `_billing_tax_number` |
| Eszközök → **Átirányítások** | a régi címek magától az új helyükre visznek; ide csak a meg nem talált régi címek kerülnek (találatszámmal) – a gyakoriaknak adj célt; tömeges betöltés „régi;új” sorokkal |
| Vezérlőpult → **Mandala őrszem** | óránkénti állapot (háttérfeladatok, hibák, rendelések, fizetések, levélküldés, feedek, tárhely, SSL); baj esetén levél megy |
| WooCommerce → **Mandala feedek** | Árukereső, Árgép, Google Merchant, Meta és Pinterest katalógus feed címei (egyszer bemásolni a szolgáltatónál); óránként frissülnek |
| WooCommerce → **Mandala SEO** | AI keresőoptimalizálás állapota (cím, meta leírás, kép alt, GYIK termékenként; napi korlát), gyűjtőoldalak |
| WooCommerce → **Mandala kuponok** | feliratkozó ablak első vásárlási kuponnal (%, érvényesség, időzítve vagy csak kilépéskor), ajánlási program (a barát kedvezménye, az ajánló jutalma), **ajándék értékhatár felett** (határ, ajándék termék cikkszáma), **születésnapi kupon** (%, érvényesség) |
| WooCommerce → **Mandala csomagok** | csomagkedvezmények (cikkszámok + %), javaslat a gyakran együtt vásárolt párokból |
| WooCommerce → **Előfizetések** | előfizetések listája (kihagyás, szüneteltetés, lemondás) és beállítások: kedvezmény, gyakoriság, előfizethető kategóriák, emlékeztető |
| WooCommerce → **Partnerek** | partnerprogram: partner felvétele (e-mail, kód, egyedi arányok), kifizetés rögzítése, alapértelmezett kedvezmény / jutalék |
| WooCommerce → **Kampányok** | szezonális kampányok sablonból (Black Friday, Karácsony, Valentin, Nőnap, Anyák napja, Újév): időszak, felső sáv, főoldali banner, kupon |
| WooCommerce → **Régi bolt beállításai** | a régi bolt fizetési módjai, szállítási zónái, adói, WooCommerce- és levélbeállításai, jogi oldalai egy lépésben (export a régi admin konzoljából, feltöltés, előnézet, átvétel, visszavonás) – ÁTADAS.md 2. pont |
| WooCommerce → **Régi bolt adatai** | a régi bolt vásárlói, rendelései (régi rendelésszámmal), kuponjai, értékelései, blogja, hiányzó oldalai és YITH ajándékkártyái – levélküldés és állapotváltás nélkül, újrafuttatható, törölhető – ÁTADAS.md 2. pont |
| **Kivonat** (bal menü) | tulajdonosi kivonat: bevétel, konverzió, tölcsér, bevételi források, AI-költség, sebesség; hétfőnként levélben (címzett: Mandala levelek → Beállítások) |
| Kivonat → **Bemutató mód** | csak dev / teszt oldalon: minden marketingeszköz demóként, minden levél az admin címre; kikapcsoláskor minden visszaáll (ATADAS.md 3b) |
| WooCommerce → Mandala feedek → **Árukereső Megbízható Bolt** | WebAPI kulcs, hozzájárulás a pénztárban, jelvény (widget) kód |
| WooCommerce → Mandala bolt adatai → **Bemutatóterem (Google)** | pontos cím, nyitvatartás napokra, koordináták, térkép és Google Cégprofil link (schema.org Store) |
| WooCommerce → **Visszaküldések** | a vásárlók által online indított visszaküldések; „Megérkezett” / „Lezárva” |
| WooCommerce → **Mandala levelek** | minden levél egy helyen: a téma automata levelei és a WooCommerce levelei (szöveg, be/ki, időzítés, előnézet, tesztlevél), **saját levelek** triggerrel, feltétellel, egyedi kuponnal (+ Új saját levél); napló. Beállítások fül: aláírás, fogyóeszköz kategóriák, értékelés-moderátor, **a GLS bővítmény csomagszám mezője** (lásd 6. pont, Csomagkövetés) |
| WooCommerce → **Ajándék és hűség** | utalvány összegek és érvényesség, ajándékcsomag, hűségpontok (gyűjtés, beváltás) |
| WooCommerce → **Mandala mérés** | Consent Mode alapállapot, saját felületek eseményei, Meta Conversions API (Pixel ID, token) |
| WooCommerce → **Mandala kereső** | szinonimák (pl. a vásárlók szavai a termékekre), népszerű keresések; havonta érdemes megnézni a „Nincs találat” listát |
| WooCommerce → **Mandala tanácsadó** | AI chat: be/ki, üdvözlő szöveg, modell, korlátok (üzenet / látogató / óra, napi összesített plafon), beszélgetések megőrzése; a beszélgetések és az értékelések átnézése (hetente érdemes) |
| Mandala levelek → **MailerLite** | API-kulcs → „Mentés és kapcsolat ellenőrzése” → hírlevél csoport (és ha kell: vásárlók, viszonteladók) → vásárlási adatok mezői → **„Meglévő lista átküldése”** (egyszer) → **„Leiratkozás-visszajelzés bekapcsolása”**. A MailerLite-ban a csoporthoz köthető az üdvözlő sorozat. Ha a MailerLite saját WooCommerce bővítménye is fut, a kosárelhagyó levelet csak az egyikben kapcsold be |
| **Adatkezelési tájékoztató** | egy bekezdés az AI tanácsadóról: a kérdéseket az Anthropic (Claude) dolgozza fel, a beszélgetést 30 napig őrizzük a szolgáltatás javításához, személyes adatot nem kérünk |
| Termékek → **Új termékek → Beállítások** | kiket értesítsen az új JUTA-termékekről, minimális leírás hossza |
| Termékek → **Új termékek → Claude migráció** | modell, küszöb, próbafuttatás (lásd `UJ-TERMEKEK.md`) |

---

## 5. Tartalom, amit nektek kell elkészíteni

- **Jogi szövegek:** ÁSZF, adatkezelési tájékoztató, impresszum, **akadálymentességi nyilatkozat** – a telepítő
  helykitöltőkkel hozza létre őket (`[kitöltendő]` részek), jogászi átnézés kell.
- **Ajándékutalvány termék:** új termék „Mandala ajándékutalvány” néven, **cikkszám: `MND-UTALVANY`** (erre mutat az
  ajándékcsomag oldal linkje), ár: a legkisebb összeg, kategória: Ajándéktárgyak, **Mandala adatok →
  Ajándékutalvány** bejelölve. Adóosztályt nem kell állítani (a téma ÁFA-mentesnek kezeli).
- **Csomagolások az ajándékcsomaghoz:** 1–3 rejtett termék (Katalógus láthatóság: rejtett), **Mandala adatok →
  Ajándékcsomagolás** bejelölve (pl. lokta papír, díszdoboz).
- **Ajándékcsomag kínálata:** a termékeknél a „Szándék” tulajdonságban az „Ajándék” érték – ezek jelennek meg az
  összeállítóban.
- **Műhelyek, események:** Műhelyek és Események menü az adminban; a termékeknél Mandala adatok → Műhely.
- **Menük:** ha a menühelyeken már van menü, a telepítő nem nyúl hozzájuk – vegyétek fel kézzel: „Ajándékcsomag és
  utalvány”, „Hangtál-választó”, „Műhelyeink”, „Események”, a lábléc jogi menüjébe „Akadálymentesség”.
- **Hangminták, egyedi darabok:** termékenként, Mandala adatok fül.

---

## 6. Próbák a tesztszerveren (élesítés előtt)

- [ ] Rendelés **Teya** teszt kártyával, **utánvéttel**, **előre utalással** – visszaigazoló levél megérkezik.
- [ ] **GLS:** futár és csomagpont; a pontválasztó a szállítási mód alatt; címke / csomagkövetés a bővítményből.
- [ ] **Számlázz.hu:** magánszemély és cég (adószámmal) – a számlán az adószám szerepel.
- [ ] **Ajándékutalvány:** vásárlás → a kód levélben (teljesítés / kártyás fizetés után) → beváltás egy másik
  rendelésnél a kuponmezőben. **A számlát a könyvelő nézze meg** (az utalvány fizetőeszköz, nem kedvezmény).
- [ ] **Viszonteladó:** belépés `wholesale_customer` felhasználóval → Fiókom → Viszonteladói felület: nagyker árak,
  gyorsrendelés, árlista, fotók.
- [ ] **JUTA:** egy új termék importja → a termék piszkozat, megjelenik a Termékek → Új termékek listában, értesítő
  levél megy; egy ár/készlet frissítés nem teszi élővé. A JUTA „Akciós ár”-a a termék **nagyker ára** lesz (a
  viszonteladó látja), a boltban nem jelenik meg akcióként. Ha az Új termékek → Beállítások fülön figyelmeztetés
  jelzi, hogy a korábbi szinkronból bolti akciós árak maradtak nagyker ár nélkül: „Áthelyezés a nagyker árba”.
- [ ] **WPML:** az angol oldalak, a nyelvválasztó, egy angol termék szűrője.
- [ ] **GTM:** előnézeti módban a `view_item_list`, `add_to_cart`, `purchase` események; a süti sáv választása a
  Consent Mode-ot frissíti. Meta pixel címkében `eventID` = `order_` + tranzakció azonosító.
- [ ] **Claude:** próbafuttatás 20–50 termékkel; a javaslatok átnézése.
- [ ] **Levelek:** WooCommerce → Mandala levelek → minden levélnél „Előnézet” és egy tesztlevél a saját címre; a szövegek
  átnézése (hangnem, aláírás). Ha a GLS bővítmény is küld „feladtuk” levelet, az egyiket kapcsold ki.
- [ ] **Csomagkövetés:** egy tesztrendelésnél a GLS bővítménnyel címkét / csomagszámot generálsz → a rendelés oldalán a
  „Csomagkövetés és levelek” dobozban megjelenik a szám, és „Feladtuk” levél megy. Ha nem jelenik meg: a rendelés
  „Egyéni mezők” dobozában keresd meg, melyik mezőbe írja a bővítmény a csomagszámot, és írd be a Mandala levelek →
  Beállítások → Csomagszám mezők listába. A „Hol a csomagom?” oldalon rendelésszám + e-mail-címmel is kipróbálható.
  Ha a boltban már volt lábléc menü, a telepítő nem írja át: a „Csomagkövetés” oldalt kézzel add hozzá
  (Megjelenés → Menük → Lábléc – Vásárlás).
- [ ] **MailerLite:** feliratkozás a lábléc űrlapján → pár percen belül a MailerLite csoportban (a mezőkkel); a
  leiratkozó link és a MailerLite-os leiratkozás mindkét irányban átmegy (a webhook élő címet igényel, tesztszerveren
  csak ha kívülről elérhető). A hibák a MailerLite fül alján látszanak.
- [ ] **AI tanácsadó:** 15–20 valódi vásárlói kérdés (ajánlás kerettel, termékoldalon „Kérdésem van”, szállítás,
  visszaküldés, egy témán kívüli kérdés); a linkelt termékek léteznek-e, az árak stimmelnek-e. A WooCommerce →
  Mandala tanácsadó oldalon a beszélgetések és a tokenek.
- [ ] Mobilon: kínálat szűrővel, termékoldal, kosár, pénztár.

---

## 7. Élesítés napja

1. Teljes mentés az éles boltról (fájlok + adatbázis).
2. A tesztszerveren bevált sorrendben: bővítmények → téma feltöltése és bekapcsolása → Mandala telepítő (ugyanazok a
   lépések, mint a teszten) → Mandala bolt adatai és a többi beállítás → gyorsítótár ürítése.
3. **Szólj a csapatnak:** a téma bekapcsolásától az importból érkező új termékek **nem kerülnek ki automatikusan** a
   boltba – a Termékek → Új termékek listában kell őket élesíteni.
4. Ellenőrzés: kezdőlap, kínálat, egy termék, kosár, egy valódi rendelés (utána sztornó), levelek.
5. A Claude migrációt élesben is próbafuttatással kezdd; a teljes futtatás után az „Élő, ellenőrizendő” lista.

**Visszaút, ha baj van:** Megjelenés → Témák → az előző téma bekapcsolása; Mandala telepítő → „Eredeti beállítások
visszaállítása”; a Claude futtatás a Claude migráció fülön visszavonható; végső esetben a mentés visszatöltése.

---

## 8. Későbbi frissítés

Új `mandala-tema.zip` → Megjelenés → Témák → Új hozzáadása → Téma feltöltése → „Jelenlegi lecserélése a
feltöltöttre”. A telepítő csak az új lépéseket futtatja, és amit kézzel módosítottatok (beállítás, oldal), azt nem
írja felül – kiírja, hogy kihagyta. A „Mandala bolt adatai” oldalon mentett adatokat a frissítés nem érinti.

A téma saját oldalai (kezdőlap, Eredetünk, Viszonteladóknak, Hangtál-választó…) a feltöltés utáni első admin
oldalbetöltéskor frissülnek, ha azóta nem szerkesztettétek őket. Ha mégis igen, a Megjelenés → Mandala telepítő
oldalon látszik, melyiket hagyta ki; ott a „pages” lépés újrafuttatható.

Termékimport közben ne cseréljetek témát: az import adagjai a téma kódját is betöltik, egy félig feltöltött téma megszakíthatja.

---

## 9. Nagy forgalom (kampány, akció, hírlevél-kiküldés)

Terheléses teszt 3000 termékkel és 5000 rendeléssel: eredmények és tanulságok a
[`TERHELESI-TESZT.md`](TERHELESI-TESZT.md) fájlban. Röviden, amit a szerveren be kell állítani:

1. **Oldal-gyorsítótár (a legfontosabb):** LiteSpeed Cache (LiteSpeed tárhelyen) vagy WP Super Cache.
   Gyorsítótár nélkül egy 4 magos szerver ~30 oldalt szolgál ki másodpercenként; gyorsítótárral ennek
   sokszorosát, mert a vendégek oldalai PHP nélkül mennek ki. A téma gyorsítótár-barát: a vendégeknek
   nincs személyes tartalom az oldalban, a kosár / kedvencek száma a böngészőben frissül, a biztonsági
   kódok lejárta (12–24 óra) nem rontja el a minikosarat és a csomagkövetést.
2. **Valódi cron percenként** (3. fejezet) – eladás után a kereső / szűrő készletadata így 1–2 percen
   belül frissül, és a háttérfeladatok (levelek, feedek, AI) nem a látogatók kérésében futnak.
3. **JSON tömörítés:** a kereső termékindexe statikus fájl (`/wp-content/uploads/mandala-index/`, 3000
   terméknél ~3 MB, tömörítve ~250 KB). Ellenőrzés: `curl -sI -H 'Accept-Encoding: gzip' <a fájl címe>` →
   `Content-Encoding: gzip`. Ha nincs, a tárhelyen kapcsold be a gzip / brotli tömörítést az
   `application/json` típusra is.
4. **Objektum-gyorsítótár (ajánlott, ha a tárhely adja):** Redis (LiteSpeed Cache → Object) – kevesebb
   adatbázis-lekérdezés a kosárban és a pénztárban.
5. **Levélküldés:** a WooCommerce a rendelés visszaigazolását a pénztár kérésében küldi; lassú SMTP-nél
   ez másodperceket adhat a „Megrendelem” gombhoz. A WP Mail SMTP-ben, ha elérhető, kapcsold be a
   háttérben küldést („Optimize Email Sending”).
6. **Terheléses próba a tesztszerveren** (élesen soha – valódi utánvétes rendeléseket ad le!):
   `BASE=https://teszt.mandala.hu VUS=20 BUYERS=2 DURATION=60 node tests/load.mjs`

---

## 10. Indulás utáni biztonsági háló (egyszer beállítani, utána magától megy)

1. **Őrszem:** Mandala levelek → Beállítások → *Őrszem* – címzett (alapból a bolt e-mail-címe). Óránként
   ellenőriz, és csak baj esetén ír (pl. „3 órája nincs rendelés, pedig ilyenkor szokott”, „nem mennek ki a
   levelek”, „állnak a háttérfeladatok”, „sok sikertelen fizetés”).
2. **Külső figyelő (5 perc, ingyenes):** [uptimerobot.com](https://uptimerobot.com) → *New monitor* → HTTP(s) →
   a Mandala levelek → Beállítások alatt látható titkos állapot-cím (`?mandala_health=…`). Akkor is jelez
   (e-mailben / SMS-ben), ha a teljes oldal vagy a szerver áll le – ezt a WordPress magáról nem tudja megírni.
3. **Átirányítások:** élesítés után egy héttel nézz rá (Eszközök → Átirányítások): a gyakran keresett, de meg
   nem talált régi címeknek adj célt. A Google Search Console „Nem található (404)” listája is ide tölthető be.
4. **Csalásvédelem:** nincs teendő. Ha tömeges kártyatesztelés indul, a pénztár magától szigorít egy órára, és
   levél jön – ilyenkor érdemes a Teya felületén a tranzakciókat megnézni.

